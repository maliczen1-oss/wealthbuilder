require('dotenv').config();
const express = require('express');
const path = require('path');
const { runStrategy } = require('./backtest');

const app = express();
app.use(express.json());
app.use(express.static(path.join(__dirname, '..', 'public')));

const PORT = process.env.PORT || 3000;

app.get('/api/health', (req, res) => {
  res.json({ ok: true, status: 'running' });
});

app.listen(PORT, () => {
  console.log(`WealthBuilder running on port ${PORT}`);
});